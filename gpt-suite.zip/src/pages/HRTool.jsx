import React from 'react';

export default function HRTool() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>📄 HR-Bewerbungsanalyse</h1>
      <p>Hier wird dein Bewerbungs-Analyzer für HR & Personalabteilungen gebaut.</p>
    </div>
  );
}
