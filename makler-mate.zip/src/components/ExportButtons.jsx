// ExportButtons.jsx – UI-Buttons für verschiedene Exportarten
// Übergibt Events nach außen: z. B. JSON speichern, Clipboard kopieren

import React from 'react';

const ExportButtons = ({ onExportJSON, onCopyClipboard }) => {
  return (
    <div style={{ marginTop: '1rem' }}>
      {/* JSON Export */}
      <button onClick={onExportJSON}>📤 Als JSON exportieren</button>

      {/* Zwischenablage-Export */}
      <button onClick={onCopyClipboard} style={{ marginLeft: '1rem' }}>
        📋 In Zwischenablage
      </button>
    </div>
  );
};

export default ExportButtons;
