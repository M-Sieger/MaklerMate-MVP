// TabbedForm.jsx – Tab-System zur Auswahl verschiedener Formulare
// Beispiel: Makler, Agentur, Bauträger

import React, { useState } from 'react';

const TabbedForm = ({ tabs }) => {
  const [activeTab, setActiveTab] = useState(Object.keys(tabs)[0]);

  return (
    <div className="tabbed-form">
      {/* Tab-Auswahl */}
      <div style={{ marginBottom: '1rem' }}>
        {Object.keys(tabs).map((key) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            style={{
              marginRight: '0.5rem',
              fontWeight: activeTab === key ? 'bold' : 'normal',
            }}
          >
            {key}
          </button>
        ))}
      </div>

      {/* Tab-Inhalt */}
      <div>{tabs[activeTab]}</div>
    </div>
  );
};

export default TabbedForm;
